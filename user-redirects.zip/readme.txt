=== User Redirects ===
Contributors: shubhcomputing
Tags: redirects, links ,shubh computing
Requires at least: 3.0.1
Tested up to: 4.4
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

User Redirects provides an easy method of redirecting requests to another page on your site.

== Description ==

User Redirects provides an easy method of redirecting links, by entering the previous url and new url. It redirects the older links to new links.

== Installation ==

1. Upload User Redirect to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Use the User Redirects screen to configure the plugin.


== Frequently Asked Question ==



== Screenshots ==

1. This screenshots description corresponds to assets/Screenshot-1.jpg.This screenshots shows the main screen of the plugin.

== Changelog ==

= 1.0 =
* Initial Release
